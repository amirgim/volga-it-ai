import csv
import os
import sys
import time
from pathlib import Path
from typing import Dict, List

import cv2
import numpy as np

from .detector import Detector
from .postprocess import mask_low_conf, normalize
from .unfold import OCR_H, OCR_W, unfold_1a

MEAN, STD = 0.5, 0.5
OCR_SIZE = (OCR_W, OCR_H)
EXTS = {".jpg", ".jpeg", ".png", ".bmp"}


def _crop(img: np.ndarray, bbox, pad: float = 0.04) -> np.ndarray:
    x1, y1, x2, y2 = bbox
    h, w = img.shape[:2]
    bw, bh = x2 - x1, y2 - y1
    x1 = max(0, int(x1 - pad * bw))
    y1 = max(0, int(y1 - pad * bh))
    x2 = min(w, int(x2 + pad * bw))
    y2 = min(h, int(y2 + pad * bh))
    return img[y1:y2, x1:x2]


def _preprocess(crop: np.ndarray) -> np.ndarray:
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    gray = cv2.resize(gray, OCR_SIZE, interpolation=cv2.INTER_LINEAR)
    x = gray.astype(np.float32) / 255.0
    x = (x - MEAN) / STD
    return x[None, None, ...]


class Pipeline:
    def __init__(self, det_weights, ocr_weights, device="cpu", use_onnx=True):
        self.device = device
        self.detector = Detector(det_weights, device=device, conf=0.3)

        self.ort = None
        self.ocr = None
        self.fallback = False
        ocr_path = Path(ocr_weights) if ocr_weights else None

        if not ocr_path or not ocr_path.exists():
            print(f"[pipeline] OCR weights not found at {ocr_weights!r}, "
                  f"using Tesseract fallback", file=sys.stderr)
            from broke.recognize import read_plate
            self._tess = read_plate
            self.fallback = True
        elif use_onnx and str(ocr_path).endswith(".onnx"):
            import onnxruntime as ort
            providers = (["CUDAExecutionProvider", "CPUExecutionProvider"]
                         if device == "cuda" else ["CPUExecutionProvider"])
            self.ort = ort.InferenceSession(str(ocr_path), providers=providers)
            self.ort_input = self.ort.get_inputs()[0].name
        else:
            import torch
            from .ocr import CRNN
            self._torch = torch
            self.ocr = CRNN()
            self.ocr.load_state_dict(torch.load(str(ocr_path), map_location=device))
            self.ocr.to(device).eval()

    def _ocr(self, x: np.ndarray) -> np.ndarray:
        if self.ort is not None:
            out = self.ort.run(None, {self.ort_input: x})[0]
            return out[0] if out.ndim == 3 else out
        with self._torch.no_grad():
            t = self._torch.from_numpy(x).to(self.device)
            return self.ocr(t)[0].cpu().numpy()

    def process(self, img: np.ndarray) -> List[Dict]:
        out: List[Dict] = []
        for d in self.detector(img):
            if d["type"] == "other":
                continue
            crop = _crop(img, d["bbox"])
            if crop.size == 0:
                continue
            if d["type"] == "type1a":
                crop = unfold_1a(crop)

            if self.fallback:
                text = self._tess(crop)
                if not text:
                    continue
                plate = normalize(text)
                ocr_conf = 0.5
            else:
                from .ocr import greedy_decode
                logits = self._ocr(_preprocess(crop))
                text, confs = greedy_decode(logits)
                text = normalize(text)
                if not text:
                    continue
                plate = mask_low_conf(text, confs, 0.35)
                ocr_conf = float(np.mean(confs)) if confs else 0.0

            if not plate or all(c == "#" for c in plate):
                continue
            if 6 <= len(plate) < 8:
                plate = plate + "#" * (8 - len(plate))
            if len(plate) not in (8, 9):
                continue
            out.append({
                "plate_num": plate,
                "plate_type": d["type"],
                "confidence": round(float(d["conf"]) * ocr_conf, 4),
            })
        return out


def run_dir(input_dir, output_csv, det_weights, ocr_weights,
            device="cpu", use_onnx=True) -> None:
    p = Pipeline(det_weights, ocr_weights, device, use_onnx)
    files = sorted(f for f in os.listdir(input_dir)
                   if os.path.splitext(f)[1].lower() in EXTS)
    rows: List[tuple] = []
    t0 = time.time()
    for f in files:
        try:
            img = cv2.imread(os.path.join(input_dir, f))
            if img is None:
                continue
            for r in p.process(img):
                rows.append((f, r["plate_num"], r["plate_type"], r["confidence"]))
        except Exception as e:  # one bad image must never kill the whole run
            print(f"[pipeline] {f}: {e}", file=sys.stderr)
    elapsed = time.time() - t0
    with open(output_csv, "w", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh, delimiter=";")
        w.writerow(["image", "plate_num", "plate_type", "confidence"])
        w.writerows(rows)
    n = max(1, len(files))
    print(f"images={len(files)} rows={len(rows)} avg_ms={elapsed / n * 1000:.1f}")
